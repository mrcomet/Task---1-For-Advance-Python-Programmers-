#!/usr/bin/env python
# coding: utf-8

# # Q1 Running Sum of 1d Array

# In[1]:


from typing import List


# In[2]:


class Solution:
    def runningSum(self, nums: List[int]) -> List[int]:
        temp=0
        res=[]
        for i in nums:
            temp+=i
            res.append(temp)
        return res


# # Q2 Shuffle the Array

# In[3]:


class Solution:
    def shuffle(self, nums: List[int], n: int) -> List[int]:
        array = []
        for i in range(n):
            array.append(nums[i])
            array.append(nums[n+i])
        return array


# # Q3  Kids With the Greatest Number of Candies

# In[4]:


class Solution:
    def kidsWithCandies(self, candies: List[int], extraCandies: int) -> List[bool]:
        x = max(candies)
        result = []
        for i in range(len(candies)):
            if candies[i] + extraCandies >= x:
                result.append(True)
            else:
                result.append(False)
        return result


# In[ ]:




